import os
from flask import Flask, render_template, request, redirect, url_for, send_file, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from io import BytesIO
from docx import Document
from docx.shared import Pt
import pathlib

try:
    from weasyprint import HTML, CSS
    WEASYPRINT_AVAILABLE = True
except Exception:
    WEASYPRINT_AVAILABLE = False

BASE_DIR = pathlib.Path(__file__).parent.resolve()
UPLOADS = BASE_DIR / 'static' / 'uploads'
UPLOADS.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + str(BASE_DIR / 'imrp_invoices.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'change-this-secret')
app.config['LOGO_PATH'] = str(UPLOADS / 'logo.jpg')

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(300), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Client(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(200))
    phone = db.Column(db.String(50))
    address = db.Column(db.Text)

class Invoice(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    invoice_no = db.Column(db.String(50), unique=True, nullable=False)
    client_id = db.Column(db.Integer, db.ForeignKey('client.id'), nullable=False)
    date = db.Column(db.Date, default=datetime.utcnow)
    items = db.relationship('InvoiceItem', backref='invoice', cascade='all, delete-orphan')

class InvoiceItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoice.id'), nullable=False)
    description = db.Column(db.String(500))
    quantity = db.Column(db.Integer, default=1)
    rate = db.Column(db.Float, default=0.0)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.before_first_request
def create_tables_and_default_admin():
    db.create_all()
    admin_user = User.query.filter_by(username=os.environ.get('ADMIN_USER', 'admin')).first()
    if not admin_user:
        default_pass = os.environ.get('ADMIN_PASS', 'admin123')
        u = User(username=os.environ.get('ADMIN_USER', 'admin'), is_admin=True)
        u.set_password(default_pass)
        db.session.add(u)
        db.session.commit()

def invoice_totals(inv):
    subtotal = sum((it.quantity or 0) * (it.rate or 0) for it in inv.items)
    tax = 0
    total = subtotal + tax
    return {'subtotal': subtotal, 'tax': tax, 'total': total}

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user)
            flash('Logged in successfully.', 'success')
            return redirect(url_for('index'))
        flash('Invalid credentials', 'error')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out.', 'success')
    return redirect(url_for('login'))

@app.route('/')
@login_required
def index():
    invoices = Invoice.query.order_by(Invoice.date.desc()).all()
    return render_template('index.html', invoices=invoices)

@app.route('/clients')
@login_required
def clients():
    clients = Client.query.all()
    return render_template('clients.html', clients=clients)

@app.route('/clients/new', methods=['GET', 'POST'])
@login_required
def new_client():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form.get('email')
        phone = request.form.get('phone')
        address = request.form.get('address')
        c = Client(name=name, email=email, phone=phone, address=address)
        db.session.add(c)
        db.session.commit()
        flash('Client created.', 'success')
        return redirect(url_for('clients'))
    return render_template('new_client.html')

@app.route('/invoices/new', methods=['GET', 'POST'])
@login_required
def new_invoice():
    clients = Client.query.all()
    if request.method == 'POST':
        invoice_no = request.form['invoice_no']
        client_id = int(request.form['client_id'])
        date_str = request.form.get('date')
        date = datetime.strptime(date_str, '%Y-%m-%d').date() if date_str else datetime.utcnow().date()
        inv = Invoice(invoice_no=invoice_no, client_id=client_id, date=date)
        db.session.add(inv)
        db.session.flush()
        descriptions = request.form.getlist('description')
        quantities = request.form.getlist('quantity')
        rates = request.form.getlist('rate')
        for d, q, r in zip(descriptions, quantities, rates):
            if not d.strip():
                continue
            item = InvoiceItem(invoice_id=inv.id, description=d.strip(), quantity=int(q or 0), rate=float(r or 0))
            db.session.add(item)
        db.session.commit()
        flash('Invoice created.', 'success')
        return redirect(url_for('index'))
    return render_template('new_invoice.html', clients=clients)

@app.route('/invoice/<int:invoice_id>')
@login_required
def view_invoice(invoice_id):
    inv = Invoice.query.get_or_404(invoice_id)
    client = Client.query.get(inv.client_id)
    totals = invoice_totals(inv)
    agency = {
        'name': 'IMRP PUBLICATION AGENCY',
        'reg': 'AS13A0000132 / UDYAM-AS-02-0011512',
        'email': 'office.imrppublication@gmail.com',
        'address': 'Nagarbera, Kamrup, Assam, 781127'
    }
    logo_path = app.config.get('LOGO_PATH') if os.path.exists(app.config.get('LOGO_PATH')) else None
    return render_template('invoice.html', invoice=inv, client=client, totals=totals, agency=agency, logo_path=logo_path)

@app.route('/invoice/<int:invoice_id>/download')
@login_required
def download_invoice_docx(invoice_id):
    inv = Invoice.query.get_or_404(invoice_id)
    client = Client.query.get(inv.client_id)
    totals = invoice_totals(inv)

    doc = Document()
    p = doc.add_paragraph()
    p.alignment = 1
    run = p.add_run('IMRP PUBLICATION AGENCY\n')
    run.bold = True
    run.font.size = Pt(14)
    p.add_run('Registration No: AS13A0000132 / UDYAM-AS-02-0011512\n')
    p.add_run('Email: office.imrppublication@gmail.com\n')
    p.add_run('Address: Nagarbera, Kamrup, Assam, 781127\n')

    doc.add_paragraph('\n')
    doc.add_paragraph(f'Invoice No: {inv.invoice_no}    Date: {inv.date.strftime("%Y-%m-%d")}')
    doc.add_paragraph(f'Bill To: {client.name}')
    if client.address:
        doc.add_paragraph(client.address)
    if client.email:
        doc.add_paragraph(f'Email: {client.email}')
    if client.phone:
        doc.add_paragraph(f'Phone: {client.phone}')

    table = doc.add_table(rows=1, cols=5)
    hdr = table.rows[0].cells
    hdr[0].text = 'Sl. No.'
    hdr[1].text = 'Description'
    hdr[2].text = 'Quantity'
    hdr[3].text = 'Rate (₹)'
    hdr[4].text = 'Amount (₹)'

    for i, it in enumerate(inv.items, start=1):
        row = table.add_row().cells
        row[0].text = str(i)
        row[1].text = it.description
        row[2].text = str(it.quantity)
        row[3].text = f'{it.rate:.2f}'
        row[4].text = f'{it.quantity * it.rate:.2f}'

    doc.add_paragraph('\n')
    doc.add_paragraph(f'Subtotal: ₹{totals['"'"']subtotal['"'"']:.2f}')
    doc.add_paragraph(f'Tax: ₹{totals['"'"']tax['"'"']:.2f}')
    doc.add_paragraph(f'Total: ₹{totals['"'"']total['"'"']:.2f}')

    doc.add_paragraph('\n')
    doc.add_paragraph('Authorized Signatory\nIMRP Publication Agency')

    f = BytesIO()
    doc.save(f)
    f.seek(0)
    filename = f'Invoice_{inv.invoice_no}.docx'
    return send_file(f, as_attachment=True, download_name=filename, mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document')

@app.route('/invoice/<int:invoice_id>/pdf')
@login_required
def download_invoice_pdf(invoice_id):
    inv = Invoice.query.get_or_404(invoice_id)
    client = Client.query.get(inv.client_id)
    totals = invoice_totals(inv)
    agency = {
        'name': 'IMRP PUBLICATION AGENCY',
        'reg': 'AS13A0000132 / UDYAM-AS-02-0011512',
        'email': 'office.imrppublication@gmail.com',
        'address': 'Nagarbera, Kamrup, Assam, 781127'
    }
    logo_path = app.config.get('LOGO_PATH') if os.path.exists(app.config.get('LOGO_PATH')) else None
    html = render_template('invoice_pdf.html', invoice=inv, client=client, totals=totals, agency=agency, logo_path=logo_path)
    if WEASYPRINT_AVAILABLE:
        css = CSS(string='''@page { size: A4; margin: 25mm } body { font-family: Arial, sans-serif; } table { width: 100%; border-collapse: collapse } table, th, td { border: 1px solid #444 } th, td { padding: 6px }''')
        pdf = HTML(string=html, base_url=str(BASE_DIR)).write_pdf(stylesheets=[css])
        return send_file(BytesIO(pdf), as_attachment=True, download_name=f'Invoice_{inv.invoice_no}.pdf', mimetype='application/pdf')
    else:
        flash('Server-side PDF generation not available (WeasyPrint not installed). You can still print to PDF from the browser view.', 'error')
        return redirect(url_for('view_invoice', invoice_id=invoice_id))

@app.route('/upload-logo', methods=['GET', 'POST'])
@login_required
def upload_logo():
    if request.method == 'POST':
        f = request.files.get('logo')
        if f:
            dest = pathlib.Path(app.config['LOGO_PATH'])
            f.save(dest)
            flash('Logo uploaded.', 'success')
            return redirect(url_for('index'))
    return render_template('upload_logo.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
