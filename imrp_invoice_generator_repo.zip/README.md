# IMRP Invoice Generator - Packaged Repo

This repository contains a Flask-based invoice generation application for IMRP Publication Agency.

Features:
- User authentication (Flask-Login)
- Client management
- Create invoices with line items, download as DOCX
- Server-side PDF generation using WeasyPrint (if installed)
- Upload and embed agency logo in PDF invoices
- Dockerfile and docker-compose for deployment

## Quickstart (local)
1. Create a virtual environment and activate it:
   ```bash
   python -m venv venv
   source venv/bin/activate   # Linux/macOS
   venv\\Scripts\\activate    # Windows PowerShell
   ```
2. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```
3. (Optional) Set admin credentials and secret key using environment variables:
   ```bash
   export ADMIN_USER=admin
   export ADMIN_PASS=admin123
   export SECRET_KEY=replace_with_a_secret
   ```
4. Run the app:
   ```bash
   flask run
   ```
5. Open `http://127.0.0.1:5000` and login with the admin credentials (default `admin` / `admin123`).

## Docker
Build and run with Docker Compose (recommended, this image installs WeasyPrint system deps):
```bash
docker-compose up --build
```
Then open `http://localhost:5000`.

## Notes about PDF generation
- The app uses WeasyPrint to generate PDFs. WeasyPrint requires native system libraries (Cairo, Pango).
- The provided Dockerfile installs minimal dependencies for WeasyPrint on Debian-based images.
- If WeasyPrint is not available on the server, PDF generation will fall back to instructing users to print-to-PDF from the browser view.

## Logo
Upload your logo on the `Upload Logo` page. The app will store it at `static/uploads/logo.jpg` and embed it into PDF invoices.

## Create admin user manually
The app automatically creates a default admin user on first run using `ADMIN_USER`/`ADMIN_PASS` environment variables or defaults to `admin`/`admin123`.

## Files
- `app.py` : main flask application
- `templates/` : Jinja2 templates
- `static/css/style.css` : styles
- `requirements.txt` : python package requirements
- `Dockerfile` and `docker-compose.yml` : for containerized deployment
